"""
gemini_utils.py
All AI orchestration for PocketSmart AI lives here: prompt construction,
calls to Gemini, response parsing, and attaching shopping links per item.

Keeping this in one utility module (rather than scattered across routes)
mirrors the architecture described in the project brief.
"""

import json
import os
import re
import urllib.parse
from io import BytesIO
from typing import Any, Dict, Optional

from PIL import Image
from pydantic import BaseModel

import google.generativeai as genai

# ---------------------------------------------------------------------------
# Model setup
# ---------------------------------------------------------------------------

_MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
_model = None


def _get_model():
    """Lazily configure and cache the Gemini model client.

    Raises a clear RuntimeError if no API key is present, instead of failing
    deep inside a request with a cryptic error.
    """
    global _model
    if _model is not None:
        return _model

    api_key = os.getenv("GOOGLE_API_KEY") or os.getenv("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "No Gemini API key found. Set GOOGLE_API_KEY (or GEMINI_API_KEY) "
            "in your .env file."
        )
    genai.configure(api_key=api_key)
    _model = genai.GenerativeModel(_MODEL_NAME)
    return _model


def extract_json_from_response(text: str) -> Dict[str, Any]:
    """Gemini sometimes wraps JSON in ```json fences or adds stray prose.
    Strip that and parse robustly."""
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?", "", cleaned.strip(), flags=re.IGNORECASE).strip()
    cleaned = re.sub(r"```$", "", cleaned.strip()).strip()

    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Fall back to grabbing the first {...} block in the text
    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        return json.loads(match.group(0))

    raise ValueError(f"Could not parse JSON from Gemini response: {text[:300]}")


def _search_link(base_url: str, param: str, terms: str) -> str:
    return f"{base_url}{urllib.parse.quote_plus(terms)}" if terms else base_url


def _add_home_shopping_links(item: Dict[str, Any]):
    terms = item.get("search_terms", "")
    item["shopping_links"] = {
        "amazon": _search_link("https://www.amazon.in/s?k=", "k", terms),
        "flipkart": _search_link("https://www.flipkart.com/search?q=", "q", terms),
        "ikea": _search_link("https://www.ikea.com/in/en/search/?q=", "q", terms),
        "myntra": _search_link("https://www.myntra.com/search?q=", "q", terms),
    }


PARTY_CATEGORY_PLATFORMS = {
    "venue": ["google", "booking", "makemytrip", "oyorooms"],
    "catering": ["swiggy", "zomato"],
    "food": ["swiggy", "zomato"],
    "drinks": ["swiggy", "zomato", "bigbasket"],
    "decoration": ["amazon", "flipkart"],
    "entertainment": ["bookmyshow", "amazon"],
    "gifts": ["amazon", "flipkart"],
    "photography": ["google", "amazon"],
    "accessories": ["amazon", "flipkart"],
}
DEFAULT_PARTY_PLATFORMS = ["amazon", "flipkart", "google"]

_PARTY_LINK_BUILDERS = {
    "amazon": lambda t: _search_link("https://www.amazon.in/s?k=", "k", t),
    "flipkart": lambda t: _search_link("https://www.flipkart.com/search?q=", "q", t),
    "bigbasket": lambda t: _search_link("https://www.bigbasket.com/ps/?q=", "q", t),
    "swiggy": lambda t: _search_link("https://www.swiggy.com/search?query=", "query", t),
    "zomato": lambda t: _search_link("https://www.zomato.com/search?q=", "q", t),
    "bookmyshow": lambda t: _search_link("https://in.bookmyshow.com/search?q=", "q", t),
    "google": lambda t: _search_link("https://www.google.com/search?q=", "q", t),
    "booking": lambda t: _search_link("https://www.booking.com/search.html?ss=", "ss", t),
    "makemytrip": lambda t: _search_link(
        "https://www.makemytrip.com/hotels/hotel-listing/?searchText=", "searchText", t
    ),
    "oyorooms": lambda t: _search_link("https://www.oyorooms.com/search/?location=", "location", t),
}


def _add_party_shopping_links(item: Dict[str, Any], category_name: str):
    terms = item.get("search_terms", "")
    if not terms:
        item["shopping_links"] = {}
        return
    platforms = PARTY_CATEGORY_PLATFORMS.get(category_name.lower(), DEFAULT_PARTY_PLATFORMS)
    item["shopping_links"] = {p: _PARTY_LINK_BUILDERS[p](terms) for p in platforms if p in _PARTY_LINK_BUILDERS}


def _add_venue_search_links(venue: Dict[str, Any]):
    terms = venue.get("search_terms", "")
    if not terms:
        venue["search_links"] = {}
        return
    venue["search_links"] = {
        "google": _PARTY_LINK_BUILDERS["google"](terms),
        "booking": _PARTY_LINK_BUILDERS["booking"](terms),
        "makemytrip": _PARTY_LINK_BUILDERS["makemytrip"](terms),
        "oyorooms": _PARTY_LINK_BUILDERS["oyorooms"](terms),
    }


def _add_jewelry_shopping_links(item: Dict[str, Any]):
    terms = item.get("search_terms", "")
    item["shopping_links"] = {
        "amazon": _search_link("https://www.amazon.in/s?k=", "k", terms),
        "flipkart": _search_link("https://www.flipkart.com/search?q=", "q", terms),
        "bluestone": _search_link("https://www.bluestone.com/search.html?query=", "query", terms),
        "tanishq": _search_link("https://www.tanishq.co.in/search?q=", "q", terms),
        "caratlane": _search_link("https://www.caratlane.com/search?q=", "q", terms),
    }


def _calc_table(result: Dict[str, Any]) -> None:
    """Build a per-category cost/percentage rollup, mutating result in place."""
    total_budget = result.get("total_budget", 0) or 0
    categories: Dict[str, Dict[str, Any]] = {}
    for category in result.get("budget_breakdown", []):
        cat_name = category.get("category", "Misc")
        bucket = categories.setdefault(
            cat_name, {"category": cat_name, "items_count": 0, "total_cost": 0.0, "percentage_of_budget": 0.0}
        )
        for item in category.get("items", []):
            bucket["items_count"] += 1
            bucket["total_cost"] += float(item.get("estimated_price", 0) or 0)
    if total_budget > 0:
        for bucket in categories.values():
            bucket["percentage_of_budget"] = round((bucket["total_cost"] / total_budget) * 100, 1)
    result["calculation_table"] = list(categories.values())


# ---------------------------------------------------------------------------
# Pydantic input models
# ---------------------------------------------------------------------------

class HomeBudgetInput(BaseModel):
    total_budget: float
    num_lights: int = 0
    num_fans: int = 0
    num_furniture: int = 0
    num_dining_tables: int = 0
    has_living_room: bool = False
    has_kitchen: bool = False
    has_bedroom: bool = False
    additional_requirements: Optional[str] = None


class PartyBudgetInput(BaseModel):
    total_budget: float
    party_type: str
    num_guests: int
    venue_type: Optional[str] = None
    needs_catering: bool = True
    needs_decoration: bool = True
    needs_entertainment: bool = False
    additional_requirements: Optional[str] = None


class JewelryBudgetInput(BaseModel):
    total_budget: float
    occasion: str
    preferences: Optional[str] = None


# ---------------------------------------------------------------------------
# Recommendation generators
# ---------------------------------------------------------------------------

def get_home_recommendations(budget_input: HomeBudgetInput) -> Dict[str, Any]:
    """Generate home interior recommendations within budget, in INR."""
    model = _get_model()
    rooms = []
    if budget_input.has_living_room:
        rooms.append("Living room")
    if budget_input.has_kitchen:
        rooms.append("Kitchen")
    if budget_input.has_bedroom:
        rooms.append("Bedroom")

    prompt = f"""
I need interior design product recommendations for a home in India with a total budget of
Rs.{budget_input.total_budget:.2f}.

Requirements:
- {budget_input.num_lights} lights/lighting fixtures
- {budget_input.num_fans} ceiling fans
- {budget_input.num_furniture} furniture pieces
- {budget_input.num_dining_tables} dining tables

Rooms to consider: {", ".join(rooms) if rooms else "Not specified"}
Additional requirements: {budget_input.additional_requirements or "None"}

Provide a detailed budget breakdown with product recommendations available in India.
Use Indian brands and realistic INR pricing. Include search terms suitable for Indian
shopping platforms (Amazon India, Flipkart, IKEA India).

Respond with ONLY valid JSON (no markdown fences, no commentary) in exactly this structure:
{{
  "total_budget": {budget_input.total_budget:.2f},
  "budget_breakdown": [
    {{
      "category": "lighting",
      "allocation": 0.0,
      "items": [
        {{"name": "", "description": "", "estimated_price": 0.0, "quantity": 0, "search_terms": ""}}
      ]
    }}
  ],
  "remaining_budget": 0.0,
  "additional_suggestions": ["", ""]
}}
Ensure total estimated costs stay within budget.
"""
    response = model.generate_content(prompt)
    result = extract_json_from_response(response.text)

    for category in result.get("budget_breakdown", []):
        for item in category.get("items", []):
            _add_home_shopping_links(item)

    _calc_table(result)
    return result


def get_party_recommendations(budget_input: PartyBudgetInput) -> Dict[str, Any]:
    """Generate party planning recommendations within budget, in INR."""
    model = _get_model()
    prompt = f"""
I need party planning recommendations for India with a total budget of Rs.{budget_input.total_budget:.2f}.

Party details:
- Type: {budget_input.party_type}
- Number of guests: {budget_input.num_guests}
- Venue type: {budget_input.venue_type or "Not specified"}
- Catering needed: {"Yes" if budget_input.needs_catering else "No"}
- Decoration needed: {"Yes" if budget_input.needs_decoration else "No"}
- Entertainment needed: {"Yes" if budget_input.needs_entertainment else "No"}
Additional requirements: {budget_input.additional_requirements or "None"}

Provide a detailed budget breakdown with specific recommendations using INR prices,
suitable for Indian vendors (Swiggy, Zomato, BookMyShow, OYO, local venues).

Respond with ONLY valid JSON (no markdown fences, no commentary) in exactly this structure:
{{
  "total_budget": {budget_input.total_budget:.2f},
  "budget_breakdown": [
    {{
      "category": "venue",
      "allocation": 0.0,
      "items": [
        {{"name": "", "description": "", "estimated_price": 0.0, "quantity": 0, "search_terms": ""}}
      ]
    }}
  ],
  "venue_suggestions": [
    {{"name": "", "type": "", "capacity": 0, "estimated_cost": 0.0, "search_terms": ""}}
  ],
  "remaining_budget": 0.0,
  "additional_suggestions": ["", ""]
}}
Ensure all costs are in INR and the total does not exceed the given budget.
"""
    response = model.generate_content(prompt)
    result = extract_json_from_response(response.text)

    for category in result.get("budget_breakdown", []):
        cat_name = category.get("category", "misc")
        for item in category.get("items", []):
            _add_party_shopping_links(item, cat_name)

    for venue in result.get("venue_suggestions", []):
        _add_venue_search_links(venue)

    _calc_table(result)
    return result


def get_jewelry_recommendations(
    budget_input: JewelryBudgetInput, image_bytes: Optional[bytes] = None
) -> Dict[str, Any]:
    """Generate jewelry recommendations, optionally analyzing an uploaded outfit image."""
    model = _get_model()
    base_prompt = f"""
I need jewelry recommendations for India with a total budget of Rs.{budget_input.total_budget:.2f}.

Occasion: {budget_input.occasion}
Preferences: {budget_input.preferences or "Not specified"}
Provide only India-relevant styles, availability, and price ranges in INR.
"""

    if image_bytes:
        img = Image.open(BytesIO(image_bytes))
        prompt = base_prompt + """
An image of the outfit is attached. Suggest jewelry that complements it, considering
color, design, and occasion appropriateness.

Respond with ONLY valid JSON (no markdown fences, no commentary) in exactly this structure:
{
  "outfit_analysis": {"colors": [], "style": "", "formality": ""},
  "total_budget": 0.0,
  "jewelry_recommendations": [
    {"item_type": "", "description": "", "style": "", "estimated_price": 0.0, "search_terms": ""}
  ],
  "remaining_budget": 0.0,
  "styling_tips": ["", ""]
}
Make sure prices are in INR and stay within budget.
"""
        response = model.generate_content([prompt, img])
    else:
        prompt = base_prompt + """
Respond with ONLY valid JSON (no markdown fences, no commentary) in exactly this structure:
{
  "total_budget": 0.0,
  "jewelry_recommendations": [
    {"item_type": "", "description": "", "style": "", "estimated_price": 0.0, "search_terms": ""}
  ],
  "remaining_budget": 0.0,
  "styling_tips": ["", ""]
}
Keep prices in INR and relevant to Indian brands.
"""
        response = model.generate_content(prompt)

    result = extract_json_from_response(response.text)

    for item in result.get("jewelry_recommendations", []):
        _add_jewelry_shopping_links(item)

    return result
