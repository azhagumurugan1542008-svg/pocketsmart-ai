"""
storage.py
Lightweight JSON-file persistence layer for PocketSmart AI.

In production you'd swap this for a real database (e.g. DynamoDB, as sketched
in the project's architecture diagram). For local development and testing,
a JSON file is enough and keeps setup to zero external services.
"""

import json
import os
import threading
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
USERS_FILE = os.path.join(DATA_DIR, "users.json")
HISTORY_FILE = os.path.join(DATA_DIR, "history.json")

_lock = threading.Lock()


def _ensure_files():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(USERS_FILE):
        with open(USERS_FILE, "w") as f:
            json.dump({}, f)
    if not os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "w") as f:
            json.dump({}, f)


def _read_json(path: str) -> Dict[str, Any]:
    _ensure_files()
    with open(path, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def _write_json(path: str, data: Dict[str, Any]):
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------

def get_user(username: str) -> Optional[Dict[str, Any]]:
    with _lock:
        users = _read_json(USERS_FILE)
        return users.get(username)


def get_user_by_email(email: str) -> Optional[Dict[str, Any]]:
    with _lock:
        users = _read_json(USERS_FILE)
        for u in users.values():
            if u.get("email", "").lower() == email.lower():
                return u
        return None


def create_user(username: str, email: str, full_name: Optional[str], hashed_password: str) -> Dict[str, Any]:
    with _lock:
        users = _read_json(USERS_FILE)
        if username in users:
            raise ValueError("Username already exists")
        user = {
            "username": username,
            "email": email,
            "full_name": full_name,
            "hashed_password": hashed_password,
            "created_at": datetime.utcnow().isoformat(),
        }
        users[username] = user
        _write_json(USERS_FILE, users)
        return user


# ---------------------------------------------------------------------------
# Recommendation history
# ---------------------------------------------------------------------------

def save_to_history(username: str, recommendation_type: str, input_data: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    with _lock:
        history = _read_json(HISTORY_FILE)
        user_history = history.setdefault(username, [])
        entry = {
            "id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow().isoformat(),
            "recommendation_type": recommendation_type,
            "input_summary": input_data,
            "result_summary": {
                "total_budget": result.get("total_budget"),
                "remaining_budget": result.get("remaining_budget"),
            },
            "full_result": result,
        }
        user_history.append(entry)
        _write_json(HISTORY_FILE, history)
        return entry


def get_history(username: str) -> List[Dict[str, Any]]:
    with _lock:
        history = _read_json(HISTORY_FILE)
        return sorted(history.get(username, []), key=lambda x: x["timestamp"], reverse=True)


def get_history_item(username: str, recommendation_id: str) -> Optional[Dict[str, Any]]:
    with _lock:
        history = _read_json(HISTORY_FILE)
        for item in history.get(username, []):
            if item["id"] == recommendation_id:
                return item
        return None
