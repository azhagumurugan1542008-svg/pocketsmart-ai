"""
app.py
PocketSmart AI - Gen AI powered budget & recommendation assistant.

FastAPI backend that ties together:
  - JWT cookie auth (register/login/logout)
  - Three budget planners (Home / Party / Jewelry) backed by Gemini
  - Recommendation history per user
  - Jinja2-rendered frontend
"""

import os
from datetime import timedelta
from typing import Optional

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.security import OAuth2PasswordRequestForm
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, EmailStr

import auth_utils
import storage
from gemini_utils import (
    HomeBudgetInput,
    JewelryBudgetInput,
    PartyBudgetInput,
    get_home_recommendations,
    get_jewelry_recommendations,
    get_party_recommendations,
)

load_dotenv()

BASE_DIR = os.path.dirname(__file__)

app = FastAPI(title="PocketSmart AI: Budget & Recommendation Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))
os.makedirs(os.path.join(BASE_DIR, "static", "uploads"), exist_ok=True)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------

class RegisterRequest(BaseModel):
    username: str
    email: EmailStr
    full_name: Optional[str] = None
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str


def _set_auth_cookie(response, token: str):
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        max_age=auth_utils.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        samesite="lax",
    )


# ---------------------------------------------------------------------------
# Public pages
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    user = await auth_utils.get_current_user_optional(request)
    return templates.TemplateResponse("index.html", {"request": request, "user": user})


@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    user = await auth_utils.get_current_user_optional(request)
    if user:
        return RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse("login.html", {"request": request, "error": None})


@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    user = await auth_utils.get_current_user_optional(request)
    if user:
        return RedirectResponse(url="/dashboard", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse("register.html", {"request": request, "error": None})


# ---------------------------------------------------------------------------
# Auth API
# ---------------------------------------------------------------------------

@app.post("/api/register")
async def register(payload: RegisterRequest):
    if storage.get_user(payload.username):
        raise HTTPException(status_code=400, detail="Username already taken")
    if storage.get_user_by_email(payload.email):
        raise HTTPException(status_code=400, detail="Email already registered")

    hashed = auth_utils.hash_password(payload.password)
    storage.create_user(payload.username, payload.email, payload.full_name, hashed)

    access_token = auth_utils.create_access_token(
        data={"sub": payload.username},
        expires_delta=timedelta(minutes=auth_utils.ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    response = JSONResponse({"message": "Account created", "username": payload.username})
    _set_auth_cookie(response, access_token)
    return response


@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = auth_utils.authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=401,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = auth_utils.create_access_token(
        data={"sub": user["username"]},
        expires_delta=timedelta(minutes=auth_utils.ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    response = JSONResponse({"access_token": access_token, "token_type": "bearer"})
    _set_auth_cookie(response, access_token)
    return response


@app.post("/logout")
async def logout(request: Request):
    token = await auth_utils.get_token(request)
    if token:
        auth_utils.blacklist_token(token)
    response = RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    response.delete_cookie(key="access_token")
    return response


# ---------------------------------------------------------------------------
# Authenticated pages
# ---------------------------------------------------------------------------

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, current_user: dict = Depends(auth_utils.get_current_user_optional)):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    recent = storage.get_history(current_user["username"])[:5]
    return templates.TemplateResponse(
        "dashboard.html", {"request": request, "user": current_user, "recent": recent}
    )


@app.get("/home-planner", response_class=HTMLResponse)
async def home_planner_page(request: Request, current_user: dict = Depends(auth_utils.get_current_user_optional)):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse("home_planner.html", {"request": request, "user": current_user, "result": None})


@app.get("/party-planner", response_class=HTMLResponse)
async def party_planner_page(request: Request, current_user: dict = Depends(auth_utils.get_current_user_optional)):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse("party_planner.html", {"request": request, "user": current_user, "result": None})


@app.get("/jewelry-planner", response_class=HTMLResponse)
async def jewelry_planner_page(request: Request, current_user: dict = Depends(auth_utils.get_current_user_optional)):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse("jewelry_planner.html", {"request": request, "user": current_user, "result": None})


@app.get("/history", response_class=HTMLResponse)
async def history_page(request: Request, current_user: dict = Depends(auth_utils.get_current_user_optional)):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    items = storage.get_history(current_user["username"])
    return templates.TemplateResponse("history.html", {"request": request, "user": current_user, "history": items})


# ---------------------------------------------------------------------------
# Planner APIs (form POST -> renders result on same page)
# ---------------------------------------------------------------------------

@app.post("/generate-home", response_class=HTMLResponse)
async def generate_home(
    request: Request,
    total_budget: float = Form(...),
    num_lights: int = Form(0),
    num_fans: int = Form(0),
    num_furniture: int = Form(0),
    num_dining_tables: int = Form(0),
    has_living_room: bool = Form(False),
    has_kitchen: bool = Form(False),
    has_bedroom: bool = Form(False),
    additional_requirements: str = Form(""),
    current_user: dict = Depends(auth_utils.get_current_user_optional),
):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    budget_input = HomeBudgetInput(
        total_budget=total_budget,
        num_lights=num_lights,
        num_fans=num_fans,
        num_furniture=num_furniture,
        num_dining_tables=num_dining_tables,
        has_living_room=has_living_room,
        has_kitchen=has_kitchen,
        has_bedroom=has_bedroom,
        additional_requirements=additional_requirements or None,
    )
    try:
        result = get_home_recommendations(budget_input)
    except Exception as e:
        return templates.TemplateResponse(
            "home_planner.html",
            {"request": request, "user": current_user, "result": None, "error": str(e)},
        )

    storage.save_to_history(current_user["username"], "home", budget_input.dict(), result)
    return templates.TemplateResponse(
        "home_planner.html", {"request": request, "user": current_user, "result": result, "error": None}
    )


@app.post("/generate-party", response_class=HTMLResponse)
async def generate_party(
    request: Request,
    total_budget: float = Form(...),
    party_type: str = Form(...),
    num_guests: int = Form(...),
    venue_type: str = Form(""),
    needs_catering: bool = Form(False),
    needs_decoration: bool = Form(False),
    needs_entertainment: bool = Form(False),
    additional_requirements: str = Form(""),
    current_user: dict = Depends(auth_utils.get_current_user_optional),
):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    budget_input = PartyBudgetInput(
        total_budget=total_budget,
        party_type=party_type,
        num_guests=num_guests,
        venue_type=venue_type or None,
        needs_catering=needs_catering,
        needs_decoration=needs_decoration,
        needs_entertainment=needs_entertainment,
        additional_requirements=additional_requirements or None,
    )
    try:
        result = get_party_recommendations(budget_input)
    except Exception as e:
        return templates.TemplateResponse(
            "party_planner.html",
            {"request": request, "user": current_user, "result": None, "error": str(e)},
        )

    storage.save_to_history(current_user["username"], "party", budget_input.dict(), result)
    return templates.TemplateResponse(
        "party_planner.html", {"request": request, "user": current_user, "result": result, "error": None}
    )


@app.post("/generate-jewelry", response_class=HTMLResponse)
async def generate_jewelry(
    request: Request,
    total_budget: float = Form(...),
    occasion: str = Form(...),
    preferences: str = Form(""),
    image: Optional[UploadFile] = File(None),
    current_user: dict = Depends(auth_utils.get_current_user_optional),
):
    if not current_user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)

    budget_input = JewelryBudgetInput(
        total_budget=total_budget, occasion=occasion, preferences=preferences or None
    )

    image_bytes = None
    if image is not None and image.filename:
        image_bytes = await image.read()

    try:
        result = get_jewelry_recommendations(budget_input, image_bytes)
    except Exception as e:
        return templates.TemplateResponse(
            "jewelry_planner.html",
            {"request": request, "user": current_user, "result": None, "error": str(e)},
        )

    input_summary = budget_input.dict()
    input_summary["has_image"] = image_bytes is not None
    storage.save_to_history(current_user["username"], "jewelry", input_summary, result)
    return templates.TemplateResponse(
        "jewelry_planner.html", {"request": request, "user": current_user, "result": result, "error": None}
    )


# ---------------------------------------------------------------------------
# History detail API
# ---------------------------------------------------------------------------

@app.get("/api/recommendation/{recommendation_id}")
async def get_recommendation_detail(
    recommendation_id: str, current_user: dict = Depends(auth_utils.get_current_user)
):
    item = storage.get_history_item(current_user["username"], recommendation_id)
    if not item:
        raise HTTPException(status_code=404, detail="Recommendation not found")
    return item


@app.get("/health")
async def health():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    print("Starting PocketSmart AI...")
    uvicorn.run("app:app", host="0.0.0.0", port=8000, reload=True)
