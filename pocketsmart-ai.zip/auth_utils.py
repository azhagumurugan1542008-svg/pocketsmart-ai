"""
auth_utils.py
Password hashing + JWT issuing/validation for PocketSmart AI.

Tokens are stored in an httponly cookie ("access_token") so the browser
carries them automatically; API clients can also send a normal
`Authorization: Bearer <token>` header.
"""

import os
from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException, Request, status
from jose import JWTError, jwt
from passlib.context import CryptContext

import storage

SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24 hours, convenient for local dev

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# tokens that have been explicitly logged out before their natural expiry
_blacklisted_tokens: set = set()


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def authenticate_user(username: str, password: str) -> Optional[dict]:
    user = storage.get_user(username)
    if not user:
        return None
    if not verify_password(password, user["hashed_password"]):
        return None
    return user


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def blacklist_token(token: str):
    _blacklisted_tokens.add(token)


async def get_token(request: Request) -> Optional[str]:
    """Pull the JWT from the cookie first, falling back to the Authorization header."""
    token = request.cookies.get("access_token")
    if token:
        return token
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.lower().startswith("bearer "):
        return auth_header.split(" ", 1)[1]
    return None


async def get_current_user(request: Request) -> dict:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
    )
    token = await get_token(request)
    if not token or token in _blacklisted_tokens:
        raise credentials_exception
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = storage.get_user(username)
    if user is None:
        raise credentials_exception
    return user


async def get_current_user_optional(request: Request) -> Optional[dict]:
    """Same as get_current_user but returns None instead of raising - for pages
    that render differently when logged in vs logged out."""
    try:
        return await get_current_user(request)
    except HTTPException:
        return None
