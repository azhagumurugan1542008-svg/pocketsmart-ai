# PocketSmart AI

A Gen-AI powered budget & recommendation assistant. Enter a budget for
**home interiors**, a **party**, or **jewelry**, and PocketSmart AI (backed by
Google Gemini) returns a curated, category-by-category shopping plan with
direct search links to Amazon, Flipkart, IKEA, Swiggy, Zomato, and more.

## What's included

```
pocketsmart-ai/
├── app.py                 # FastAPI app - all routes (pages + APIs)
├── gemini_utils.py         # Gemini prompt building, calls, shopping links
├── auth_utils.py            # JWT auth (hashing, tokens, cookie sessions)
├── storage.py                # JSON-file persistence (users + history)
├── requirements.txt
├── .env.example              # copy to .env and fill in your API key
├── static/
│   └── styles.css
├── templates/                # Jinja2 HTML pages
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── dashboard.html
│   ├── home_planner.html
│   ├── party_planner.html
│   ├── jewelry_planner.html
│   └── history.html
└── data/                     # auto-created: users.json, history.json
```

Note on storage: the project brief's architecture diagram shows DynamoDB / S3
/ AWS Lambda. For local development this build uses simple JSON files
instead (`data/users.json`, `data/history.json`) so you can run everything
with zero cloud setup. The code is structured so swapping `storage.py` for a
real database later is a self-contained change — nothing else needs to know.

## 1. Prerequisites

- Python 3.10+ installed
- A Google Gemini API key: https://aistudio.google.com/apikey (free tier works)
- VS Code (or any editor) with the Python extension

## 2. Setup in VS Code

1. **Open the folder**
   `File > Open Folder...` → select `pocketsmart-ai`.

2. **Create a virtual environment** (open a terminal in VS Code: `` Ctrl+` ``)
   ```bash
   python -m venv venv
   ```
   Activate it:
   - macOS / Linux: `source venv/bin/activate`
   - Windows (PowerShell): `venv\Scripts\Activate.ps1`

   In VS Code, select this interpreter: `Ctrl+Shift+P` → "Python: Select
   Interpreter" → choose the one inside `venv`.

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure your API key**
   ```bash
   cp .env.example .env
   ```
   Open `.env` and paste your real key:
   ```
   GOOGLE_API_KEY=your_actual_key_here
   SECRET_KEY=some-long-random-string
   ```
   `.env` holds secrets — never commit it. (`.env.example` is the safe,
   committable template.)

## 3. Run the app

```bash
uvicorn app:app --reload
```
or simply:
```bash
python app.py
```

Then open **http://127.0.0.1:8000** in your browser.

## 4. Using it

1. Click **Get started** → create an account (stored locally, password
   hashed with bcrypt).
2. From the dashboard, open any of the three planners.
3. Fill in a budget and the relevant details, submit, and Gemini generates
   a structured recommendation with shopping links per item.
4. Every generated plan is saved to **History**, viewable per user.

## 5. Testing it

**Manual smoke test (recommended first run):**
1. Register a user → confirm you land on `/dashboard`.
2. Home planner: budget 5000, 5 lights, 2 fans, 3 furniture, 1 dining
   table → submit → confirm a categorized breakdown with shopping links
   appears and doesn't exceed the budget.
3. Party planner: budget 10000, 20 guests, "Birthday" → submit → confirm
   venue suggestions and category breakdown appear.
4. Jewelry planner: budget 5000, occasion "Wedding", upload any photo →
   submit → confirm an outfit analysis + jewelry list appears.
5. Visit `/history` → confirm all three runs are listed.
6. Log out, log back in → confirm history persists (it's in `data/`).

**API health check:**
```bash
curl http://127.0.0.1:8000/health
# {"status": "ok"}
```

**Automatic docs:** FastAPI serves interactive Swagger docs at
`http://127.0.0.1:8000/docs` — useful for exercising `/api/register`,
`/token`, and `/api/recommendation/{id}` directly.

## 6. Common issues

| Symptom | Fix |
|---|---|
| `RuntimeError: No Gemini API key found` | You forgot to fill in `.env`, or didn't restart the server after editing it. |
| `ModuleNotFoundError` | Your venv isn't activated, or `pip install -r requirements.txt` didn't run in it. |
| Login redirects back to `/login` | Cookies blocked, or `SECRET_KEY` changed between restarts (old tokens become invalid — just log in again). |
| Gemini returns malformed JSON occasionally | `gemini_utils.extract_json_from_response` already strips markdown fences and retries a regex fallback; if it still fails, the planner page shows the raw error — try again, LLM output can be non-deterministic. |

## 7. Notes for going further

- Swap `storage.py`'s JSON files for a real database (Postgres, DynamoDB) by
  keeping the same function signatures (`get_user`, `create_user`,
  `save_to_history`, `get_history`, ...).
- The third-party "shopping links" are search-URL deep links, not live API
  calls — wiring up real product APIs (Amazon PA-API, Flipkart Affiliate
  API, etc.) is a drop-in replacement inside `gemini_utils.py`'s
  `_add_*_shopping_links` helpers.
- Rotate `SECRET_KEY` and set a real domain-restricted `allow_origins` list
  in `app.py`'s CORS config before deploying anywhere public.
